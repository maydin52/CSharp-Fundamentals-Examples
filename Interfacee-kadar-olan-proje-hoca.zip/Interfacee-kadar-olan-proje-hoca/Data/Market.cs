﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsApp1.Models;

namespace WinFormsApp1.Data
{
    internal static class Market
    {
        static List<Urun> _urunler = new List<Urun>();
        public static void UrunEkle(Urun urun)
        {
            _urunler.Add(urun);
        }

        public static List<Urun> TumUrunler()
        {
           return _urunler;
        }

        //Raporlar...
        public static List<Urun> KirikUrunler()
        {
            List<Urun> _kirikUrunler = new List<Urun>();
            foreach (Urun urun in _urunler)
            {
                if (urun is IKirilabilir)
                { 
                    
                     if(((IKirilabilir)urun).KirikMi)
                        _kirikUrunler.Add(urun);
                }
            }
            return _kirikUrunler;
        }

        public static List<Urun> BozukUrunler()
        {
            return _urunler;
        }

        public static List<Urun> TavsiyeEdilenTarihiGecmisUrunler()
        {
            return _urunler;
        }
    }
}
