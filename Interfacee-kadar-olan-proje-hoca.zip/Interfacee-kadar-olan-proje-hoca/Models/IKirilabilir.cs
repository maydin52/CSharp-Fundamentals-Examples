﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.Models
{
    internal interface IKirilabilir
    {
        public bool KirikMi { get; set; }
    }
}
