﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.Models
{
    internal class Yumurta : Urun, IKirilabilir, ISKT
    {
        public DateTime SKT { get; set; }
        public bool KirikMi { get; set; }

        public override string ToString()
        {
            return $"{UrunID} {UrunAdi} {Fiyat} {KirikMi} {SKT}";
        }
    }
}
