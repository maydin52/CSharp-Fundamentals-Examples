﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.Models
{
    internal class KagitHavlu:Urun
    {
        public override string ToString()
        {
            return $"{UrunID} {UrunAdi} {Fiyat}";
        }
    }
}
