﻿using System.Linq.Expressions;
using WinFormsApp1.Data;
using WinFormsApp1.Models;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            Market.UrunEkle(new Bardak { UrunID = 101, UrunAdi = "6 lı Su Bardagi", Fiyat = 110, KirikMi = false });
            Market.UrunEkle(new Bardak { UrunID = 103, UrunAdi = "6 lı cay Bardagi", Fiyat = 75, KirikMi = true });

            Market.UrunEkle(new Bulgur { UrunID = 112, UrunAdi = "İnce Bulgur", Fiyat = 25, TETT = new DateTime(2023, 6, 30) });
            Market.UrunEkle(new Bulgur { UrunID = 115, UrunAdi = "İri Bulgur", Fiyat = 30, TETT = new DateTime(2023, 8, 30) });


            Market.UrunEkle(new KagitHavlu { UrunID = 121, UrunAdi = "24lu Kagit Havlu", Fiyat = 230 });

            Market.UrunEkle(new SiseSut { UrunID = 135, UrunAdi = "Gunluk Inek Sutu", Fiyat = 40, KirikMi = false, SKT = new DateTime(2023, 7, 25) });
            Market.UrunEkle(new SiseSut { UrunID = 136, UrunAdi = "Gunluk Keci Sutu", Fiyat = 80, KirikMi = false, SKT = new DateTime(2023, 7, 22) });

            Market.UrunEkle(new Yogurt { UrunID = 156, UrunAdi = "1kg Tam yaglı Yogurt", Fiyat = 40, SKT = new DateTime(2023, 8, 12) });

            Market.UrunEkle(new Yumurta { UrunID = 186, UrunAdi = "6lı MBoy Yumurta", Fiyat = 25, KirikMi = false, SKT = new DateTime(2023, 8, 12) });
            Market.UrunEkle(new Yumurta { UrunID = 187, UrunAdi = "12lı MBoy Yumurta", Fiyat = 45, KirikMi = true, SKT = new DateTime(2023, 8, 10) });
            Market.UrunEkle(new Yumurta { UrunID = 189, UrunAdi = "12lı MBoy Gezen Yumurta", Fiyat = 55, KirikMi = true, SKT = new DateTime(2023, 7, 12) });

        }

        private void btnTumUrunler_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = Market.TumUrunler();
        }

        private void btnKiriklar_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = Market.KirikUrunler();
        }
    }
}